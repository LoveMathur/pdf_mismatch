from __future__ import annotations

from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field

from models.bounding_box import BoundingBox
from models.text_element import TextElement


class LogicalElementType(str, Enum):
    """
    Semantic type of a logical element.
    """

    TEXT = "text"

    LABEL = "label"

    VALUE = "value"

    PARAGRAPH = "paragraph"

    TABLE = "table"

    TABLE_CELL = "table_cell"

    IMAGE = "image"

    CAPTION = "caption"

    HEADER = "header"

    FOOTER = "footer"

    UNKNOWN = "unknown"


class LogicalElement(BaseModel):
    """
    Semantic representation of one meaningful unit inside a document.

    Unlike TextElement, which mirrors PDF extraction,
    LogicalElement represents what a human would naturally identify
    as a single piece of information.
    """

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    id: str = Field(default_factory=lambda: str(uuid4()))

    # ------------------------------------------------------------------
    # Source
    # ------------------------------------------------------------------

    source_elements: list[TextElement]

    # ------------------------------------------------------------------
    # Content
    # ------------------------------------------------------------------

    text: str

    comparison_text: str

    # ------------------------------------------------------------------
    # Position
    # ------------------------------------------------------------------

    page_number: int

    bbox: BoundingBox

    reading_order: int

    # ------------------------------------------------------------------
    # Semantic information
    # ------------------------------------------------------------------

    element_type: LogicalElementType = LogicalElementType.TEXT

    field_id: str | None = None

    # ------------------------------------------------------------------
    # Extensibility
    # ------------------------------------------------------------------

    metadata: dict[str, Any] = Field(default_factory=dict)

    def __str__(self) -> str:
        return self.text

    @property
    def is_header(self) -> bool:
        return self.element_type == LogicalElementType.HEADER

    @property
    def is_footer(self) -> bool:
        return self.element_type == LogicalElementType.FOOTER

    @property
    def is_table(self) -> bool:
        return self.element_type == LogicalElementType.TABLE

    @property
    def is_image(self) -> bool:
        return self.element_type == LogicalElementType.IMAGE

    @property
    def is_field(self) -> bool:
        return self.field_id is not None