from pydantic import BaseModel


class LogicalWord(BaseModel):
    """
    Smallest semantic unit in the document.

    Every annotation ultimately points to one of these.
    """

    id: str

    page: int

    line_id: str

    word_index: int

    text: str

    bbox: tuple[float, float, float, float]

    font: str = ""

    font_size: float = 0.0

    color: int = 0

    flags: int = 0

    rotation: float = 0.0

    metadata: dict = {}

    class Config:
        arbitrary_types_allowed = True