from pydantic import BaseModel

from models.logical_word import LogicalWord
from models.span import Span


class LogicalLine(BaseModel):
    """
    Represents one readable line in the PDF.

    This becomes the primary unit of comparison.
    """

    id: str

    page: int

    text: str

    bbox: tuple[float, float, float, float]

    words: list[LogicalWord]

    spans: list[Span]

    reading_order: int

    is_header: bool = False

    is_footer: bool = False

    is_table: bool = False

    is_caption: bool = False

    metadata: dict = {}

    class Config:
        arbitrary_types_allowed = True