from pydantic import BaseModel

from models.logical_page import LogicalPage


class LogicalDocument(BaseModel):
    """
    Top-level logical representation of a PDF.

    This is the only object that the comparison engine
    should consume.
    """

    file_name: str

    pages: list[LogicalPage]

    metadata: dict = {}

    class Config:
        arbitrary_types_allowed = True