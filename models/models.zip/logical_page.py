from pydantic import BaseModel

from models.logical_line import LogicalLine


class LogicalPage(BaseModel):
    """
    Logical representation of a single PDF page.
    """

    page_number: int

    width: float

    height: float

    lines: list[LogicalLine]

    metadata: dict = {}

    class Config:
        arbitrary_types_allowed = True