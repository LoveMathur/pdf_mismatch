from comparators.base import Comparator
from models.difference_group import DifferenceGroup
from models.logical_aligned_pair import LogicalAlignedPair


class ComparisonEngine:

    def __init__(
        self,
        comparators: list[Comparator],
    ):
        self.comparators = comparators

    def compare(
        self,
        aligned_pairs: list[LogicalAlignedPair],
    ) -> list[DifferenceGroup]:

        groups: list[DifferenceGroup] = []

        for pair in aligned_pairs:

            for comparator in self.comparators:

                groups.extend(
                    comparator.compare(pair)
                )

        return groups